/*trapezoid is a quadrilateral
parallegram is a trapezoid
rectangle is a parallelogram
square is a rectangle*/
class Point
{
	
}
class Quadrilateral
{

}

class Trapezoid extends Quadrilateral
{

}

class Parallelogram extends Trapezoid
{

}

class Rectangle extends Parallelogram
{

}

class Square extends Rectangle
{

}

class QuadrilateralMain
{
	public static void main(String args[])
	{

	}
}
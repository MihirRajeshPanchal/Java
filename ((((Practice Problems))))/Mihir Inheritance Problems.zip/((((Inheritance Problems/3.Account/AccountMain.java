class Account
{

}

class SavingsAccount extends Account
{
	int interest;
}

class CurrentAccount extends Account
{
	int limit;
}

class AccountMain
{

}